const CryptoJs = require("crypto-js");
const jwt = require("jsonwebtoken");
const Donor = require("../Models/Donor");
const dotenv = require("dotenv");
dotenv.config();

// REGISTER DONOR
const registerDonor = async (req, res) => {
  try {
    const encryptedPassword = CryptoJs.AES.encrypt(
      req.body.password,
      process.env.PASS
    ).toString();

    const newDonor = new Donor({
      name: req.body.name,
      email: req.body.email,
      password: encryptedPassword,
    });

    const savedDonor = await newDonor.save();
    res.status(201).json(savedDonor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// LOGIN DONOR
const loginDonor = async (req, res) => {
  try {
    const user = await Donor.findOne({ email: req.body.email });
    if (!user) {
      return res.status(401).json({ error: "Donor not registered" });
    }

    if (!user.password || !process.env.PASS) {
      return res.status(500).json({ error: "Missing password or encryption key" });
    }

    const decrypted = CryptoJs.AES.decrypt(user.password, process.env.PASS);
    const originalPassword = decrypted.toString(CryptoJs.enc.Utf8);

    if (originalPassword !== req.body.password) {
      return res.status(401).json({ error: "Wrong password" });
    }

    const { password, ...info } = user._doc;

    const accessToken = jwt.sign(
      { id: user._id },
      process.env.JWT_SEC,
      { expiresIn: "10d" }
    );

    res.status(200).json({ ...info, accessToken });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: error.message });
  }
};


//Create Donor
const createDonor = async(req, res) => {
   try {
      const newDonor = Donor(req.body);
      const donor = await newDonor.save();
      res.status(201).json(donor);                                                                                                 
   } catch (error) {
      res.status(500).json(error);                                                                                                                                                                                      
   }                                                                                                    
}

//getAllDonor
const getAllDonor = async(req, res) => {
   try {
      const donors = await Donor.find().sort({createdAt: -1})
      res.status(200).json(donors)                                                                                                 
   } catch (error) {
      res.status(500).json(error)                                                                                                 
   }                                                                                                     
}

   
//Update Donor
const updateDonor = async (req, res) => {
   try {
      const updateDonor = await Donor.findByIdAndUpdate(
         req.params.id,
         { $set: req.body },
         { new: true }                                                                                              
      )    
      res.status(201).json(updateDonor)                                                                                                                                                                                              
   } catch (error) {
      res.status(500).json(error)                                                                                                                                                                                              
   }                                                                                                     
}

//getOneDonor
const getOneDonor = async(req, res) => {
   try {
       const donor = await Donor.findById(req.params.id);
       res.status(200).json(donor);                                                                                                
   } catch (error) {
       res.status(500).json(error)                                                                                                 
   }                                                                                                     
}

//deleteDonor
const deleteDonor = async (req, res) => {
   try {
      await Donor.findByIdAndDelete(req.params.id); 
      res.status(201).json("Donor deleted Successfully");                                                                                                 
   } catch (error) {
      res.status(500).json(error)                                                                                                   
   }                                                                                                    
}

//Stats
const getDonorStats = async (req, res) => {
   try {
      const stats = await Donor.aggregate([
         {
            $group: {
               _id: "$bloodgroup",
               count: { $sum: 1 }                                                                                        
            }                                                                                           
         }                                                                                              
      ]);
      
      res.status(200).json(stats);    
   } catch (error) {
       res.status(500).json(error)                                                                                                 
   }                                                                                                    
}

module.exports = { deleteDonor, getOneDonor, getAllDonor, getDonorStats, updateDonor, createDonor, loginDonor, registerDonor }