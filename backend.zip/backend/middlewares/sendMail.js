const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();

const transport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    }
});

// Function to send eligibility email
const sendEligibilityEmail = async (to, isEligible) => {
    const subject = isEligible ? 'Registration Successful' : 'Ineligibility Notification';
    const message = isEligible
        ? 'Congratulations! You have successfully registered as a blood donor.'
        : 'Unfortunately, you do not meet the criteria to donate blood at this time.';

    await transport.sendMail({
        from: process.env.EMAIL_USER,
        to,
        subject,
        text: message,
    });
};

// Export both transport and function
module.exports = {
    transport,
    sendEligibilityEmail
};
