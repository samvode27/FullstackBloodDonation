const express = require("express");
const { createHospital, getAllHospitals, updateHospital, getOneHospital, deleteHospital, getHospitalStats, signup, signin, sendVerificationCode, verifyVerificationCode, changePassword, sendForgotPasswordCode, verifyForgotPasswordCode, profileUpdate, updateProfile } = require("../cotrollers/hospital");
const router = express.Router();
const { identifier } = require('../middlewares/identification');
const { verifyToken } = require("../middlewares/verifyToken");
const Hospital = require("../Models/Hospital");


const multer = require("multer");
const path = require("path");

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Save to 'uploads' folder
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9) + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});

// Create the upload middleware
const upload = multer({ storage });

router.post('/signup', signup)
router.post('/signin', signin)

router.patch('/sendverificationcode', identifier, sendVerificationCode)
router.patch('/verifyverificationcode', identifier, verifyVerificationCode)
router.patch('/changepassword', identifier, changePassword)

router.patch('/sendforgotpasswordcode', sendForgotPasswordCode)
router.patch('/verifyforgotpasswordcode', verifyForgotPasswordCode)

router.put('/profile/update', verifyToken, profileUpdate)


//add Hospital
router.post('/', createHospital)

//get all Hospitals
router.get('/', getAllHospitals)

//update hospitals
router.put('/:id', updateHospital)

//get One Hospital
router.get('/find/:id', getOneHospital)

//delete Hospital
router.delete('/:id', deleteHospital)

//donor Hospital Stats
router.get('/stats', getHospitalStats)

router.put("/:id", identifier, updateProfile);

router.post("/uploadprofile", identifier, upload.single("image"), updateProfile);

router.post('/uploadprofile', identifier, upload.single("image"), async (req, res) => {
  try {
    const hospital = await Hospital.findById(req.user.userId);
    if (!hospital) return res.status(404).json({ success: false, message: "Hospital not found" });

    hospital.profileImage = `/uploads/${req.file.filename}`;
    await hospital.save();

    res.status(200).json({ success: true, message: "Profile picture uploaded", profileImage: hospital.profileImage });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error uploading profile" });
  }
});


module.exports = router;